#include "MarbleGlobal.h"
#ifdef __GNUC__
#warning global.h is deprecated. Please #include <marble/MarbleGlobal.h> instead (no further changes needed).
#endif
